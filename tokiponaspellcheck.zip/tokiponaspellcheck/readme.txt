For macOS users, this will add all Toki Pona words recorded by linku.la to your personal dictionary, preventing spellcheck from flagging them.

Compatibility:
- This script only works on macOS. However, feel free to modify it for your own operating system.
- This script requires Unix and BASH.

Instructions:
1. Pull or download this however you like. Make sure to keep everything in the same directory, or it won't work.
2. run chmod +x tpspellcheck.sh
3. run ./tpspellcheck.sh
4. Restart your device (or necessary apps) for changes to take effect.

Note on AI:
- Because this script was made entirely with AI, I'd like to note this was because I simply did not take the time to use $ man commands and didn't know about the LocalDictionary directory. Please use this script however you'd like without credit because of this. Also because it's such a simple script.
