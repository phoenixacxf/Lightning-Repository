#!/bin/bash

# The following script using Claude Sonnet 4.5 by Anthropic on 2026-01-15. Only reason is because I'm new to scripting, and didn't know that the LocalDictionary directory existed. With that being said, I am still going to push this so that people can do this more easily if they wish. However, I will only push it in the main directory, and not make a new repository or branch. The word list I'm using is made by cross-referencing with Linku.la. All words in the tpwords.txt file are from their dictionary. I will try to update the tpwords.txt file as words are added to their dictionary, but I can't guarantee anything. Feel free to use this one however you want. No need for credits, this is incredibly basic.

# Pretty obvious note, this script ONLY works with macOS.

# Output tpwords.txt into the LocalDictionary directory.
cat tpwords.txt >> ~/Library/Spelling/LocalDictionary

# Removes duplicate words, then ensures that it remains in the LocalDictionary directory.
sort -u ~/Library/Spelling/LocalDictionary -o ~/Library/Spelling/LocalDictionary
